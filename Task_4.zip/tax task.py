cost=int(input("cost of a meal: "))
tax=int(input("tax of local: "))
t=cost*tax/100
tip=cost*18/100
print("tax amount is:",t)
print("tip amount is:",tip)
print("grant amount is: ",cost+t+tip)
